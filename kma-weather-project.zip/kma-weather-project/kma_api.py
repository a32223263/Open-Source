import requests
from datetime import datetime, timedelta

# 단기예보 데이터를 가져오는 함수
def get_forecast(api_key: str, nx: int, ny: int):
    # 기상청 단기예보 API 엔드포인트(요청 주소)
    endpoint = "https://apihub.kma.go.kr/api/typ02/openApi/VilageFcstInfoService_2.0/getVilageFcst"
    
    # 기상청 API가 요구하는 'base_date'와 'base_time' 계산
    # 기상청 API는 3시간 단위(2, 5, 8, 11, 14, 17, 20, 23시)로 데이터 발표

    now = datetime.now()
    
    # API 서버에 데이터가 반영되는 시간을 고려하여 3시간 전을 기준으로 계산
    target_time = now - timedelta(hours=3)
    base_date = target_time.strftime('%Y%m%d')
    
    hour = target_time.hour # 기준 시간을 3시간 단위로
    if hour < 2:
        base_time = "2300" 
        base_date = (target_time - timedelta(days=1)).strftime('%Y%m%d')
    elif hour < 5:
        base_time = "0200"  # 2시 ~ 5시 사이는 02시 자료
    elif hour < 8:
        base_time = "0500"
    elif hour < 11:
        base_time = "0800"
    elif hour < 14:
        base_time = "1100"
    elif hour < 17:
        base_time = "1400"
    elif hour < 20:
        base_time = "1700"
    elif hour < 23:
        base_time = "2000"
    else:
        base_time = "2300"

    # API에 전송할 파라미터(요청 변수) 설정
    params = {
        'pageNo': '1',
        'numOfRows': '1000',
        'dataType': 'JSON',
        'base_date': base_date,
        'base_time': base_time,
        'nx': str(nx),
        'ny': str(ny),
        'authKey': api_key
    }

    try:
        # requests 라이브러리를 사용해 기상청 서버에 GET 요청 전송
        res = requests.get(endpoint, params=params, timeout=10)
        res.raise_for_status()
        
        data = res.json() # 응답받은 텍스트를 JSON(딕셔너리)으로 변환

        # API 응답 헤더의 결과 코드가 '00' (정상)이 아닌 경우
        if data.get('response', {}).get('header', {}).get('resultCode') != '00':
            error_msg = data.get('response', {}).get('header', {}).get('resultMsg', '알 수 없는 오류')
            print(f"단기예보 API 응답 오류 : {error_msg}")
            return None

        # 실제 날씨 데이터가 있는 'item' 리스트를 가져옴
        items = data.get('response', {}).get('body', {}).get('items', {}).get('item')
        
        if not items: return None # 데이터가 없으면 None 반환

        # 필요한 데이터만 추출하여 저장할 딕셔너리
        weather_data = {}
        for item in items:
            category = item.get('category') # 데이터 종류 ('TMP', 'PCP')
            value = item.get('fcstValue')   # 데이터 값 ('23.5', '강수없음')

            # 'T1H' -> 'TMP' (단기예보 기온 코드)
            # 'RN1' -> 'PCP' (단기예보 1시간 강수량 코드)

            # 'weather_data'에 해당 키가 없을 때만 (가장 빠른 예보 시간) 값을 저장
            if category == 'TMP' and 'temp' not in weather_data: weather_data['temp'] = value
            elif category == 'PCP' and 'precip' not in weather_data: weather_data['precip'] = value
            elif category == 'SKY' and 'sky' not in weather_data: weather_data['sky'] = value
            elif category == 'PTY' and 'pty' not in weather_data: weather_data['pty'] = value
            elif category == 'WSD' and 'wind_speed' not in weather_data: weather_data['wind_speed'] = value
            
            # 모든 데이터를 찾았으면 반복 중단
            if all(k in weather_data for k in ['temp', 'precip', 'sky', 'pty', 'wind_speed']): break
        
        return weather_data
    except requests.exceptions.RequestException as e: # 네트워크 연결 오류 또는 타임아웃 발생 시
        print(f"단기예보 API 요청 중 네트워크 오류 발생: {e}")
        return None
    except Exception as e: # JSON 파싱 오류 등 기타 예외 발생 시
        print(f"데이터 처리 중 오류 발생: {e}")
        return None

# 위성 영상 URL을 가져오는 함수
def get_satellite_image_url(api_key: str):
    # 기상청 위성 이미지 API 엔드포인트
    # API 문서 "9. (그래픽) 천리안 2A 분포도"에 명시된 URL 구조를 사용
    base_url = "https://apihub.kma.go.kr/api/typ03/cgi/sat/nph-gk2a_img"
    
    # KST(한국 표준시) 기준 15분 여유시간
    now_kst = datetime.now()
    search_time = now_kst - timedelta(minutes=15)
    
    # 분을 가장 가까운 10분 단위로 맞춤 (59분 -> 50분, 34분 -> 30분)
    minute = (search_time.minute // 10) * 10
        
    # 10분 단위로 맞춘 시간으로 최종 요청 시간을 설정
    search_time = search_time.replace(minute=minute, second=0, microsecond=0)
    
    # API가 요구하는 yyyymmddhhmm 형식으로 최종 시간을 만듦
    time_str = search_time.strftime("%Y%m%d%H%M")

    # 최종적으로 이미지의 전체 URL을 조합
    image_url = f"{base_url}?tm={time_str}&obs=ir105&map=HR&grid=2&legend=0&size=600&authKey={api_key}"
    
    print(f"요청된 위성 영상 URL: {image_url}") # 디버깅을 위해 URL을 터미널에 출력
    return image_url