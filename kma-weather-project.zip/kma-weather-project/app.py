import time
import random
from flask import Flask, render_template, url_for
from kma_api import get_forecast, get_satellite_image_url

app = Flask(__name__)

# 기상청에서 발급받은 실제 서비스 키
KMA_API_KEY = "2fqF3fBYST-6hd3wWEk_RA" 

def get_sky_status(sky_code: str, pty_code: str) -> str:
    """하늘 상태와 강수 형태 코드를 한글 텍스트로 변환"""
    if pty_code != 0: # 강수 O
        pty_map = {
            1: '비', 2: '비/눈', 3: '눈', 
            4: '소나기', 5: '빗방울', 
            6: '빗방울/눈날림', 7: '눈날림'
        }
        return pty_map.get(pty_code, "알 수 없는 강수")
    else: # 강수 X 일 때만 하늘 상태 코드 확인
        sky_map = {'1': '맑음', '3': '구름많음', '4': '흐림'}
        return sky_map.get(sky_code, "알 수 없음")

# 라우팅 정의 (페이지 URL 연결)
@app.route('/')
def index():
    """메인 페이지 : 현재 날씨 핵심 정보 표시"""
    # 서울 종로구의 기상청 격자 좌표
    nx, ny = 60, 127
    
    # kma_api.py의 함수를 호출하여 기상청에서 데이터를 가져옴
    forecast_data = get_forecast(KMA_API_KEY, nx, ny)
    satellite_url = get_satellite_image_url(KMA_API_KEY)

    if not forecast_data:
        # get_forecast가 None을 반환하면 에러 페이지 표시
        return render_template('error.html', message="기상청 단기예보 API에서 데이터를 가져오는 데 실패했습니다.")

    # API 원시 데이터를 HTML에서 쓰기 좋게
    temp = float(forecast_data.get('temp', '0'))
    wind_speed = float(forecast_data.get('wind_speed', '0'))
    precip_str = forecast_data.get('precip', '0')
    precip = 0.0 if '강수없음' in precip_str else float(precip_str)
    
    # 문자열 형태로 오는 PTY 값을 정수로 변환
    pty_value = int(forecast_data.get('pty', '0'))

    # HTML 템플릿으로 전달할 최종 데이터 딕셔너리(context) 구성
    processed_data = {
        "location": "종로구",
        "date": time.strftime("%Y년 %m월 %d일"),    # 현재 날짜
        "time": time.strftime("%H:%M"),             # 현재 시간
        "T1H": temp,                                # 기온
        "RN1": precip,                              # 강수량
        "WSD": wind_speed,                          # 풍속
        "SKY": forecast_data.get('sky', '0'),       # 하늘 상태
        "PTY": pty_value,                           # 강수 형태

        # 아래는 API로 제공되지 않아 임시로 생성한 가상 데이터 => 나중에 고칠 것
        "REH": random.randint(50, 80),              # 습도
        "SENSIBLE_TEMP": temp - 2.5,                # 체감 온도
        "LOCAL_RADAR_INDEX": round(random.uniform(5.0, 40.0), 1), # 레이더 값
        "LOCAL_RADAR_UNIT": "dBZ",
        "RADAR_SOURCE": "KMA HSR 합성장"
    }

    # SKY, PTY를 한글 텍스트로 변환
    sky_status_text = get_sky_status(processed_data['SKY'], processed_data['PTY'])

    # 최종적으로 HTML 템플릿에 전달할 모든 데이터를 'context' 객체로 묶음
    context = {
        "page_title": "현재 날씨",          # base.html의 <title>에 들어갈 값
        "data": processed_data,             # 날씨 데이터 묶음
        "sky_status": sky_status_text,      # 변환된 한글 하늘 상태
        "satellite_url": satellite_url      # 위성 이미지 URL
    }
    # 'index.html' 파일을 HTML로 변환하고, context 데이터 주입
    return render_template('index.html', **context)

# forecast 경로를 위한 함수
@app.route('/forecast')
def forecast():
    """상세 예보 페이지 : 시간별 상세 예보 데이터 테이블 표시"""
    hourly_simulated_data = []
    base_temp = random.uniform(15.0, 25.0)
    for i in range(1, 7):
        hourly_simulated_data.append({
            "hour": (int(time.strftime("%H")) + i) % 24,    # 현재 시간부터 1~6시간 뒤
            "temp": round(base_temp + random.uniform(-1.5, 1.0), 1),
            "rain_prob": random.randint(10, 80),
            "wind_spd": round(random.uniform(1.0, 4.0), 1)
        })

    # HTML 템플릿('forecast.html')에 전달할 context 데이터
    context = {
        "page_title": "상세 예보",
        "hourly_data": hourly_simulated_data
    }
    return render_template('forecast.html', **context)

# 사용자가 '/radar' URL에 접속했을 때
@app.route('/radar')
def radar():
    """기상 영상 페이지 : 천리안 2A 위성 영상 표시"""
    satellite_url = get_satellite_image_url(KMA_API_KEY)
    
    # HTML 템플릿('radar.html')에 전달할 context 데이터
    context = {
        # 'page_title' 변수에 현재 시간을 넣어, radar.html에서 "최신(XX:XX 기준)"으로 표시
        "page_title": time.strftime("%Y-%m-%d %H:%M"),
        "satellite_url": satellite_url
    }
    return render_template('radar.html', **context)

if __name__ == '__main__':
    app.run(debug=True)